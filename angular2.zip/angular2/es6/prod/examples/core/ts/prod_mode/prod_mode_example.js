import { enableProdMode } from 'angular2/core';
import { bootstrap } from 'angular2/platform/browser';
import { MyComponent } from './my_component';
enableProdMode();
bootstrap(MyComponent);
// #enddocregion
