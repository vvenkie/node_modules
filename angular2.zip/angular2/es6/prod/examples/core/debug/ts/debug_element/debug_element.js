var debugElement;
var predicate;
// #docregion scope_all
debugElement.query(predicate);
// #enddocregion
