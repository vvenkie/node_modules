export * from 'angular2/src/http/backends/mock_backend';
