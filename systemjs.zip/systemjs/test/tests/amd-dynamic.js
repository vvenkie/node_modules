define(function() {
  return 'dynamic';
});