A = 'A';

B = 'B';

C = 'C';