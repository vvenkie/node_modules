"format global";
export var p = 'value';