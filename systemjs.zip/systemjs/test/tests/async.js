// will detect as CommonJS
if (false) require('asdf');

// should detect as ES6 first
export async function p() {}