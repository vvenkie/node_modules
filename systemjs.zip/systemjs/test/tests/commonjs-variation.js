module.exports = {
  e: (function p() {
    return require('@empty');
  })()
}