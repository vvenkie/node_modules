module.exports = {
  nonce: 'ab'
};
