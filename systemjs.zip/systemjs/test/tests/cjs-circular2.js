var first = require('./cjs-circular1.js').first;
exports.p = function() {
  return first;
}