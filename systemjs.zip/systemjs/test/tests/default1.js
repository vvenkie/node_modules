import q from './default1-dep.js';
export default 'default1';
export var d = 'default1';