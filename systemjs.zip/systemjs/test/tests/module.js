import * as default3 from "./default3.js";

export var test = default3.default;