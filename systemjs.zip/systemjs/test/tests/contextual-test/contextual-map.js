module.exports = require('maptest');
