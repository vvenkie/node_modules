var p = module.exports = function() {

}

p.someExport = 'asdf';