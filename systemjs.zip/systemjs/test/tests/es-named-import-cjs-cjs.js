exports.cjsFunc = function() {
  return 'named export';
};