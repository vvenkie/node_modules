module.exports = 'path';
