(function(window) {
  window.jjQuery = {
    v: '1.8.3'
  };
})(typeof window != 'undefined' ? window : global);