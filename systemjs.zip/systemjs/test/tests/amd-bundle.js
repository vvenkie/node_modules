define('bundle-1', function() {
  return { defined: true };
});
define('bundle-2', function() {
  return { defined: true };
});