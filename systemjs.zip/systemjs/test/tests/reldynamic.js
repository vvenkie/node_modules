

export function dynamicLoad() {
  return System.import('./reldynamicdep.js', __moduleName);
}
