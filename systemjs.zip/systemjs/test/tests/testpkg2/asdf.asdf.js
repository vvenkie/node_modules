define({
  asdf: 'asdf'
});