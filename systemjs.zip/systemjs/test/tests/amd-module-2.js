define([
  './amd-module.js',
  '@empty',
], function () {
  return { amd: true };
});