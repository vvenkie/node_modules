(function(global) {
  global.emptyES6 = true;
})(typeof window == 'undefined' ? global : window);