"format es6";

class q {
}


