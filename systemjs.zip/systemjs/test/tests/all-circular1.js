import { a } from './all-circular2.js';
export var q;
export function p() {
  q = a;
}

import o from './all-circular3.js';

export { o };