(typeof window != 'undefined' ? window : global).depCacheTest = 'passed';
