define(function() {
  return true;
})