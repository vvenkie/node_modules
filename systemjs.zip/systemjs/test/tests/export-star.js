export * from './star-dep.js';
export var bar = 'bar';