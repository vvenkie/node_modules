
import {x} from './local-esm';

export var q = 'q';
export var fromLocal = x;