
var local = require('./local-cjs');

exports.q = 'q';

exports.fromLocal = local.x;
