
import local from './local-default-esm';

export var q = 'q';
export var fromLocal = local;

import localDirect from './local/index-default-esm.js';

export var fromLocalDirect = localDirect;

