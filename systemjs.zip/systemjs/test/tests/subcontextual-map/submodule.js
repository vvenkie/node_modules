define(['dep'], function(dep) {
  return dep;
});