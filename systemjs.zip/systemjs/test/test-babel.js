System.transpiler = 'babel';
System.baseURL = 'test/';
require('./test');