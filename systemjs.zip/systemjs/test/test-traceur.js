System.transpiler = 'traceur';
System.baseURL = 'test/';
require('./test');