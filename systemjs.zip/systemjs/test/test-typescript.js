global.ts = require('typescript');
System.transpiler = 'typescript';
System.baseURL = 'test/';
require('./test');