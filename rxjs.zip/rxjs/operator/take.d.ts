import { Observable } from '../Observable';
export declare function take<T>(total: number): Observable<T>;
