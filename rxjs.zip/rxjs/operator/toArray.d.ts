import { Observable } from '../Observable';
export declare function toArray<T>(): Observable<T[]>;
