import { ConnectableObservable } from '../observable/ConnectableObservable';
export declare function publishLast<T>(): ConnectableObservable<T>;
