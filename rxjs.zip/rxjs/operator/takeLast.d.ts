import { Observable } from '../Observable';
export declare function takeLast<T>(total: number): Observable<T>;
