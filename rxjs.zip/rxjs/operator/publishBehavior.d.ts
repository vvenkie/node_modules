import { ConnectableObservable } from '../observable/ConnectableObservable';
export declare function publishBehavior<T>(value: T): ConnectableObservable<T>;
