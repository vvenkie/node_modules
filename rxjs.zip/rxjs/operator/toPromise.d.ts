export declare function toPromise<T>(PromiseCtor?: typeof Promise): Promise<T>;
