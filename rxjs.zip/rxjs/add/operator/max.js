"use strict";
var Observable_1 = require('../../Observable');
var max_1 = require('../../operator/max');
var observableProto = Observable_1.Observable.prototype;
observableProto.max = max_1.max;
//# sourceMappingURL=max.js.map