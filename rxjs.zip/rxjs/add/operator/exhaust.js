"use strict";
var Observable_1 = require('../../Observable');
var exhaust_1 = require('../../operator/exhaust');
var observableProto = Observable_1.Observable.prototype;
observableProto.exhaust = exhaust_1.exhaust;
//# sourceMappingURL=exhaust.js.map