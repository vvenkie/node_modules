"use strict";
var Observable_1 = require('../../Observable');
var pairwise_1 = require('../../operator/pairwise');
var observableProto = Observable_1.Observable.prototype;
observableProto.pairwise = pairwise_1.pairwise;
//# sourceMappingURL=pairwise.js.map