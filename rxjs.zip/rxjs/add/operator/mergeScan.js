"use strict";
var Observable_1 = require('../../Observable');
var mergeScan_1 = require('../../operator/mergeScan');
var observableProto = Observable_1.Observable.prototype;
observableProto.mergeScan = mergeScan_1.mergeScan;
//# sourceMappingURL=mergeScan.js.map