"use strict";
var Observable_1 = require('../../Observable');
var exhaustMap_1 = require('../../operator/exhaustMap');
var observableProto = Observable_1.Observable.prototype;
observableProto.exhaustMap = exhaustMap_1.exhaustMap;
//# sourceMappingURL=exhaustMap.js.map