"use strict";
var Observable_1 = require('../../Observable');
var min_1 = require('../../operator/min');
var observableProto = Observable_1.Observable.prototype;
observableProto.min = min_1.min;
//# sourceMappingURL=min.js.map