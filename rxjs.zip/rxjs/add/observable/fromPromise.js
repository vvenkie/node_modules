"use strict";
var Observable_1 = require('../../Observable');
var PromiseObservable_1 = require('../../observable/PromiseObservable');
Observable_1.Observable.fromPromise = PromiseObservable_1.PromiseObservable.create;
//# sourceMappingURL=fromPromise.js.map