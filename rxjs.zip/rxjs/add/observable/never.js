"use strict";
var Observable_1 = require('../../Observable');
var NeverObservable_1 = require('../../observable/NeverObservable');
Observable_1.Observable.never = NeverObservable_1.NeverObservable.create;
//# sourceMappingURL=never.js.map