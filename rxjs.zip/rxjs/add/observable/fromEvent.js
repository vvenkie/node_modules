"use strict";
var Observable_1 = require('../../Observable');
var FromEventObservable_1 = require('../../observable/FromEventObservable');
Observable_1.Observable.fromEvent = FromEventObservable_1.FromEventObservable.create;
//# sourceMappingURL=fromEvent.js.map