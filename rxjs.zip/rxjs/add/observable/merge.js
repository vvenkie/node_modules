"use strict";
var Observable_1 = require('../../Observable');
var merge_1 = require('../../operator/merge');
Observable_1.Observable.merge = merge_1.mergeStatic;
//# sourceMappingURL=merge.js.map