"use strict";
var Observable_1 = require('../../Observable');
var RangeObservable_1 = require('../../observable/RangeObservable');
Observable_1.Observable.range = RangeObservable_1.RangeObservable.create;
//# sourceMappingURL=range.js.map