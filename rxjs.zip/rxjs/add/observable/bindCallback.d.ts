export declare var _void: void;
