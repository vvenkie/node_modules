"use strict";
var Observable_1 = require('../../Observable');
var EmptyObservable_1 = require('../../observable/EmptyObservable');
Observable_1.Observable.empty = EmptyObservable_1.EmptyObservable.create;
//# sourceMappingURL=empty.js.map