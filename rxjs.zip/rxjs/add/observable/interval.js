"use strict";
var Observable_1 = require('../../Observable');
var IntervalObservable_1 = require('../../observable/IntervalObservable');
Observable_1.Observable.interval = IntervalObservable_1.IntervalObservable.create;
//# sourceMappingURL=interval.js.map