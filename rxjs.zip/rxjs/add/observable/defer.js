"use strict";
var Observable_1 = require('../../Observable');
var DeferObservable_1 = require('../../observable/DeferObservable');
Observable_1.Observable.defer = DeferObservable_1.DeferObservable.create;
//# sourceMappingURL=defer.js.map