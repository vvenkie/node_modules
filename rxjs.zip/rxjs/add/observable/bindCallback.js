"use strict";
var Observable_1 = require('../../Observable');
var BoundCallbackObservable_1 = require('../../observable/BoundCallbackObservable');
Observable_1.Observable.bindCallback = BoundCallbackObservable_1.BoundCallbackObservable.create;
//# sourceMappingURL=bindCallback.js.map