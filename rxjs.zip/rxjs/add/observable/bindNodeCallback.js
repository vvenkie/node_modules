"use strict";
var Observable_1 = require('../../Observable');
var BoundNodeCallbackObservable_1 = require('../../observable/BoundNodeCallbackObservable');
Observable_1.Observable.bindNodeCallback = BoundNodeCallbackObservable_1.BoundNodeCallbackObservable.create;
//# sourceMappingURL=bindNodeCallback.js.map