"use strict";
var Observable_1 = require('../../Observable');
var TimerObservable_1 = require('../../observable/TimerObservable');
Observable_1.Observable.timer = TimerObservable_1.TimerObservable.create;
//# sourceMappingURL=timer.js.map