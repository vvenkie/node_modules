"use strict";
var Observable_1 = require('../../../Observable');
var WebSocketSubject_1 = require('../../../observable/dom/WebSocketSubject');
Observable_1.Observable.webSocket = WebSocketSubject_1.WebSocketSubject.create;
//# sourceMappingURL=webSocket.js.map