"use strict";
var Observable_1 = require('../../../Observable');
var AjaxObservable_1 = require('../../../observable/dom/AjaxObservable');
Observable_1.Observable.ajax = AjaxObservable_1.AjaxObservable.create;
//# sourceMappingURL=ajax.js.map