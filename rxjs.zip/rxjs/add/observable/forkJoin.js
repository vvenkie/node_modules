"use strict";
var Observable_1 = require('../../Observable');
var ForkJoinObservable_1 = require('../../observable/ForkJoinObservable');
Observable_1.Observable.forkJoin = ForkJoinObservable_1.ForkJoinObservable.create;
//# sourceMappingURL=forkJoin.js.map