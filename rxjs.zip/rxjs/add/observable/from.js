"use strict";
var Observable_1 = require('../../Observable');
var FromObservable_1 = require('../../observable/FromObservable');
Observable_1.Observable.from = FromObservable_1.FromObservable.create;
//# sourceMappingURL=from.js.map