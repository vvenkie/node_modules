"use strict";
var Observable_1 = require('../../Observable');
var ArrayObservable_1 = require('../../observable/ArrayObservable');
Observable_1.Observable.fromArray = ArrayObservable_1.ArrayObservable.create;
Observable_1.Observable.of = ArrayObservable_1.ArrayObservable.of;
//# sourceMappingURL=fromArray.js.map