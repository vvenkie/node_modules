"use strict";
var Observable_1 = require('../../Observable');
var FromEventPatternObservable_1 = require('../../observable/FromEventPatternObservable');
Observable_1.Observable.fromEventPattern = FromEventPatternObservable_1.FromEventPatternObservable.create;
//# sourceMappingURL=fromEventPattern.js.map