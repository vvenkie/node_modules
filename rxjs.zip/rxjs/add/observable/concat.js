"use strict";
var Observable_1 = require('../../Observable');
var concat_1 = require('../../operator/concat');
Observable_1.Observable.concat = concat_1.concatStatic;
//# sourceMappingURL=concat.js.map